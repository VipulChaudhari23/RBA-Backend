package com.thinknxt.rba.dto;

import com.thinknxt.rba.config.Generated;

import lombok.Data;

@Data
@Generated
public class LoginDTO {
    private int userId;
    private String password;
}
