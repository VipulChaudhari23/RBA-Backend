package com.thinknxt.rba.utils;

import com.thinknxt.rba.config.Generated;

@Generated
public enum NotificationStatus {
 
	Txn_Confirmation,
	Account_balance_updates,
	Low_balance_alerts,
	Security_alerts,
	Account_block_alerts,
	Email,
	SMS,
	NA;
}