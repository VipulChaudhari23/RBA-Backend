package com.thinknxt.rba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import com.thinknxt.rba.config.Generated;

@SpringBootApplication
@Generated
@EnableDiscoveryClient
public class RbaAccountsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RbaAccountsApplication.class, args);
	}

}
