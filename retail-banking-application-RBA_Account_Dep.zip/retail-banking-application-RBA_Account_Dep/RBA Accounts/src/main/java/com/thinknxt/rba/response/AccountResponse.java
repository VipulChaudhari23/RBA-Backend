package com.thinknxt.rba.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.thinknxt.rba.config.Generated;
import com.thinknxt.rba.dto.CustomerDTO;
import com.thinknxt.rba.entities.Accounts;
import com.thinknxt.rba.entities.Customer;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated
public class AccountResponse {

    private int statusCode;
    private String statusMessage;
    private Customer data; // Use the DTO instead of the actual Customer entity
    private List<Accounts> accounts;

    public AccountResponse(int statusCode, String statusMessage, Customer data, List<Accounts> accounts) {
        this.statusCode = statusCode;
        this.statusMessage = statusMessage;
        this.data = data;
        this.accounts = accounts;
    }
}
