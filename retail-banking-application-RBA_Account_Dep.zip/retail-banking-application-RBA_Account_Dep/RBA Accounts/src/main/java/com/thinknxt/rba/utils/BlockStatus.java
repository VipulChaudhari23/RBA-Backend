package com.thinknxt.rba.utils;
 
import com.thinknxt.rba.config.Generated;
 
@Generated
public enum BlockStatus {
 
	CREDITBLOCKED,
	DEBITBLOCKED,
	BLOCKED,
	ACTIVE,
	BOTH,
	CREDITUNBLOCK,
	DEBITUNBLOCK
}