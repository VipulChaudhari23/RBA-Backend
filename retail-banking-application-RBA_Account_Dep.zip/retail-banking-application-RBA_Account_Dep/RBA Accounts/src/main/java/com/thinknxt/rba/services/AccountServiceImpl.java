package com.thinknxt.rba.services;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.thinknxt.rba.dto.CustomerAccountDTO;
import com.thinknxt.rba.dto.CustomerDTO;
import com.thinknxt.rba.dto.EmailRequest;
import com.thinknxt.rba.dto.TicketDTO;
import com.thinknxt.rba.entities.Accounts;
import com.thinknxt.rba.entities.Customer;
import com.thinknxt.rba.entities.Ticket;
import com.thinknxt.rba.repository.AccountRepository;
import com.thinknxt.rba.repository.TicketRepository;
import com.thinknxt.rba.response.BudgetSetupResponse;
import com.thinknxt.rba.response.CustomerAccountResponse;
import com.thinknxt.rba.response.CustomerResponse;
import com.thinknxt.rba.response.NotificationResponse;
import com.thinknxt.rba.utils.BlockStatus;
import com.thinknxt.rba.utils.NotificationStatus;

import jakarta.persistence.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AccountServiceImpl implements AccountService {

	private AccountRepository accountRepository;

	@Autowired
	private TicketRepository ticketRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	public AccountServiceImpl(AccountRepository accountRepository) {
		this.accountRepository = accountRepository;
	}

	/**
	 * Retrieves accounts for a given customer ID.
	 *
	 * @param customerId The ID of the customer.
	 * @return CustomerAccountResponse containing accounts, status, and message.
	 */
	@Override
	public CustomerAccountResponse getCustomerAccounts(int customerid) {
		// Log entry point of the method with customer ID
		log.info("Retrieving accounts for customer ID: {}", customerid);

		List<Accounts> accounts = accountRepository.findByCustomerid(customerid);

		if (accounts.isEmpty()) {
			// Log a message when no accounts are found
			log.info("No accounts found for the customer ID: {}", customerid);
			return new CustomerAccountResponse(null, 201, "No accounts found for the customer");
		} else {
			// Log a message when accounts are retrieved successfully
			log.info("Accounts retrieved successfully for customer ID: {}", customerid);
			return new CustomerAccountResponse(accounts, 200, "Accounts retrieved successfully");
		}
	}

	public String fetchAccountStatusService(long account_number) {
		log.info("Inside fetchAccountStatusService function of AccountServiceImpl class ");

		Accounts accountStatus = accountRepository.findByAccountnumber(account_number);

		if (ObjectUtils.isEmpty(accountStatus)) {
			return null;
		} else {
			return accountStatus.getAccountstatus();
		}
	}

	public String updateAccountStatus(Long account_number, String accountStatus, String reason) {
		log.info("Inside updateAccountStatus function of AccountServiceImpl class ");

		Accounts account_Status = accountRepository.findByAccountnumber(account_number);
		if (!ObjectUtils.isEmpty(accountStatus)) {
			account_Status.setAccountstatus(accountStatus);
			account_Status.setBlockreason(reason);
			accountRepository.save(account_Status);

			String getCustomerUrl = "http://192.168.97.44:1011/api/retailbanking/customer/getCustomerDetails/"
					+ account_Status.getCustomerid();
			ResponseEntity<CustomerDTO> customerResponseEntity = restTemplate.getForEntity(getCustomerUrl,
					CustomerDTO.class);

			if (customerResponseEntity != null) {

				int cust_Id = 0;
				String getNotificationDTOUrl = "http://192.168.97.44:1011/api/retailbanking/customer/getNotificationData/"
						+ cust_Id + "/" + account_number;
				ResponseEntity<NotificationResponse> notificationData = restTemplate.getForEntity(getNotificationDTOUrl,
						NotificationResponse.class);
				String blockAlert = notificationData.getBody().getData().getAccountBlockAlerts();
				if (notificationData != null && blockAlert.equalsIgnoreCase(NotificationStatus.Email.toString())) {

					String subject = "Account Transaction Status Update.";

					String body = String.format(
							"Dear %s,\n\n" + "Your account %s" + " has been %s.\n"
									+ "For more information kindly contact branch. \n\n"
									+ "Thank you for banking with us,\n" + "Maveric Banks",
							customerResponseEntity.getBody().getFirstName() + " "
									+ customerResponseEntity.getBody().getLastName(),
							account_number, accountStatus, account_Status.getCustomerid());

					String url = "http://192.168.97.44:1014/email/sendEmail";

					String mailResponse = "";

					EmailRequest request = new EmailRequest(customerResponseEntity.getBody().getEmail(), subject, body);
					ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
					if (response.getStatusCode().is2xxSuccessful()) {
						mailResponse = "Email has been sent successfully to mail Id :"
								+ customerResponseEntity.getBody().getEmail();
					} else {
						mailResponse = "Failed to send email.";
					}
				}
			}
			log.info("Account Status Updated as " + accountStatus);
			return "Successfully " + accountStatus;

		} else {
			return "Unable to update.";
		}
	}

	@Override
	public CustomerAccountDTO createAccount(int customerId, String accountType) {
		CustomerAccountDTO customerAccountDTO = new CustomerAccountDTO();
		// Log entry point of the method createAccount
		log.info("Creating account for customer ID: {}", customerId);
		Long accountNumber = Long.valueOf(generateUniqueAccountNumber(customerId));
		Accounts newAccount = new Accounts();
		newAccount.setAccountnumber(accountNumber);
		newAccount.setAccountnumber(accountNumber);
		newAccount.setAccounttype(accountType);
		newAccount.setCreationdate(LocalDateTime.now());
		newAccount.setAccountstatus("ACTIVE");
		newAccount.setCurrency("INR");
		newAccount.setCustomerid(customerId);
		newAccount.setOverdraft("NO");
		newAccount.setTotalbalance(0);
		accountRepository.save(newAccount);

		String customerMicroserviceUrl = "http://192.168.97.44:1011/api/retailbanking/customer/updateAccountNumber/"
				+ newAccount.getCustomerid() + "/" + newAccount.getAccountnumber();
		ResponseEntity<NotificationResponse> responseEntity = restTemplate.postForEntity(customerMicroserviceUrl, null,
				NotificationResponse.class);
		String transactionMicroserviceUrl = "http://192.168.97.44:1013/api/retailbanking/transactions/addBudget/accountNumber/"
				+ accountNumber;

		ResponseEntity<BudgetSetupResponse> responseEntityForAddingBudget = restTemplate
				.postForEntity(transactionMicroserviceUrl, null, BudgetSetupResponse.class);

		customerAccountDTO.setMsg("Account Created Successfully");
		customerAccountDTO.setStatus(200);
		return customerAccountDTO;
	}

	private String generateUniqueAccountNumber(int customerId) {

		List<Accounts> accounts = accountRepository.findByCustomerid(customerId);

		if (accounts.isEmpty()) {
			// Log a message when no accounts are found
			log.info("No accounts found for the customer ID: {}", customerId);
			log.info("Creating new account for the customer ID: {}", customerId);

			return customerId + "001";
		} else {
			// Log a message when accounts are retrieved successfully
			log.info("Accounts retrieved successfully for customer ID: {}", customerId);
			Accounts maxAccount = accounts.stream().max(Comparator.comparingLong(Accounts::getAccountnumber))
					.orElse(null);

			if (maxAccount != null) {
				return String.valueOf(maxAccount.getAccountnumber() + 1);
			}
			return null;
		}
	}

	public Accounts fetchAccountDetailsService(long account_number) {
		log.info("Inside fetchAccountDetailsService function of AccountServiceImpl class ");

		Accounts account = accountRepository.findByAccountnumber(account_number);

		if (ObjectUtils.isEmpty(account)) {
			return null;
		} else {
			return account;
		}
	}

	@Override
	@Transactional
	public void updateAmount(Double newAmount, long accountNumber) {
		Accounts accountsEntity = accountRepository.findByAccountnumber(accountNumber);
		if (accountsEntity != null) {
			accountsEntity.setTotalbalance(newAmount);
			accountRepository.save(accountsEntity);
		}
	}

	/**
	 * Author: Vipul New UI Implementation Retrieves a list of accounts for a given
	 * customer ID.
	 *
	 * @param customerId The ID of the customer.
	 * @return List of accounts for the specified customer ID.
	 */
	@Override
	@Transactional(readOnly = true)
	public List<Accounts> getAccountsByCustomerId(int customerId) {
		try {
			log.info("Retrieving accounts for customer ID: {}", customerId);

			List<Accounts> accounts = accountRepository.findByCustomerid(customerId);

			// Filter accounts with status "closed" or "deleted"
			List<Accounts> filteredAccounts = accounts.stream()
					.filter(account -> !("CLOSED".equalsIgnoreCase(account.getAccountstatus())
							|| "deleted".equalsIgnoreCase(account.getAccountstatus())))
					.collect(Collectors.toList());

			log.info("Accounts retrieved successfully for customer ID: {}", customerId);

			return filteredAccounts;
		} catch (Exception ex) {
			log.error("Error while retrieving accounts for customer ID: {}", customerId, ex);

			throw new RuntimeException("Error while retrieving accounts", ex);
		}
	}

	@Override
	@Transactional(readOnly = true)
	public boolean areAccountsMappedToCustomer(int customerId) {
		try {
			log.info("Checking if accounts are mapped for customer ID: {}", customerId);

			List<Accounts> accounts = accountRepository.findByCustomerid(customerId);

			log.info("Accounts retrieved successfully for customer ID: {}", customerId);

			return !accounts.isEmpty(); // Return true if accounts are mapped, false otherwise
		} catch (Exception ex) {
			log.error("Error while checking if accounts are mapped for customer ID: {}", customerId, ex);

			throw new RuntimeException("Error while checking if accounts are mapped", ex);
		}
	}

	@Override
	public List<Accounts> getAllAccounts() {
		// Implement your logic to fetch accounts from the repository
		return accountRepository.findAll();
	}

	/**
	 * @author siddharth Creates a new ticket based on the provided TicketDTO. Sets
	 *         ticket details from the TicketDTO and saves the ticket using the
	 *         ticketRepository. Logs the created ticket object.
	 *
	 * @param ticketDTO The ticket data transfer object containing ticket details.
	 * @return The newly created ticket.
	 */
	@Override
	public Ticket createTicket(TicketDTO ticketDTO) {
		Ticket ticket = new Ticket();
		ticket.setTicketType(ticketDTO.getTicketType());
		ticket.setCustomerId(ticketDTO.getCustomerId());
		ticket.setAccountNumber(ticketDTO.getAccountNumber());
		ticket.setAccountType(ticketDTO.getAccountType());
		ticket.setRecipientAccountNumber(ticketDTO.getRecipientAccountNumber());
		ticket.setTransferFund(ticketDTO.getTransferFund());
		ticket.setFeedback(ticketDTO.getFeedback());

		log.info("Created ticket: {}", ticket);

		return ticketRepository.save(ticket);
	}



	/**
	 * @author siddharth Checks if a ticket exists for the given customerId,
	 *         accountNumber, and ticketType.
	 *
	 * @param ticketDTO The ticket data transfer object containing customer ID,
	 *                  account number, and ticket type.
	 * @return True if a ticket exists with the given details, false otherwise.
	 */
	@Override
	public boolean isTicketExists(TicketDTO ticketDTO) {
		// Check if a ticket exists for the given customerId, accountNumber, and
		// ticketType
		return ticketRepository.existsByCustomerIdAndAccountNumberAndTicketType(ticketDTO.getCustomerId(),
				ticketDTO.getAccountNumber(), ticketDTO.getTicketType());
	}


	/**
	 * @author siddharth Retrieves all tickets.
	 *
	 * @return A list of all tickets.
	 */
	@Override
	public List<Ticket> getAllTickets() {
		return ticketRepository.findAll();
	}

	/**
	 * @author Siddharth Updates a ticket with the provided ticket ID and TicketDTO.
	 *         Fetches the existing ticket by ID, updates its details from the
	 *         TicketDTO, and saves the updated ticket.
	 *
	 * @param ticketId  The ID of the ticket to be updated.
	 * @param ticketDTO The ticket data transfer object containing updated ticket
	 *                  details.
	 * @return The updated ticket.
	 * @throws EntityNotFoundException If no ticket found with the provided ID.
	 */
	@Override
	public Ticket updateTicket(Long ticketId, TicketDTO ticketDTO) {
		// Fetch the existing ticket by ticketId
		Ticket existingTicket = ticketRepository.findById(ticketId)
				.orElseThrow(() -> new EntityNotFoundException("Ticket not found with id: " + ticketId));

		// Update ticket details from ticketDTO
		existingTicket.setTicketType(ticketDTO.getTicketType());
		existingTicket.setCustomerId(ticketDTO.getCustomerId());
		existingTicket.setAccountNumber(ticketDTO.getAccountNumber());
		existingTicket.setAccountType(ticketDTO.getAccountType());
		existingTicket.setRecipientAccountNumber(ticketDTO.getRecipientAccountNumber());
		existingTicket.setTicketStatus(ticketDTO.getTicketStatus());
		existingTicket.setTransferFund(ticketDTO.getTransferFund());
		existingTicket.setFeedback(ticketDTO.getFeedback());

		// Save the updated ticket
		return ticketRepository.save(existingTicket);
	}

	@Override
	public Ticket getTicket(Long ticketId) {
		log.info("Fetching ticket from ticketId : " + ticketId);
		return ticketRepository.findById(ticketId)
				.orElseThrow(() -> new EntityNotFoundException("Ticket not found with id: " + ticketId));
	}

	/**
	 * @author siddharthsh Closes the account with the specified account number.
	 * 
	 * @param accountNumber The account number of the account to be closed.
	 * @return A string indicating the status of the account closure: - "mailSent"
	 *         if the account was closed successfully and the email notification was
	 *         sent successfully. - "mailFailed" if the account was closed
	 *         successfully but the email notification failed to send. -
	 *         "mailNotFound" if the account was closed successfully but the
	 *         customer's email address was not found. - "nonZero" if the account
	 *         balance is not zero and the account cannot be closed.
	 * @throws RuntimeException if the account with the specified account number is
	 *                          not found.
	 */
	@Override
	@Transactional
	public String closeAccount(Long accountNumber) {
		Accounts account = accountRepository.findById(accountNumber)
				.orElseThrow(() -> new RuntimeException("Account not found"));
		if (account.getTotalbalance() == 0) {
			account.setAccountstatus("CLOSED");
			accountRepository.save(account);
			log.info("Account with account number {} closed successfully", accountNumber);
			// Fetch the customerId from the account details using the accountNumber.
			Accounts accountDetails = fetchAccountDetailsService(accountNumber);
			int customerId = accountDetails.getCustomerid();
			// Fetch customer details from the customer microservice to retrieve email
			// address
			Customer customer = getCustomer(customerId);
			if (customer != null) {
				// Get the customer's registered email address.
				String email = customer.getEmail();
				String subject = "Account Closure for Account No. " + accountNumber;
				String transferFunds = ""; // Added this option if we have to notify the fund transfer details related
											// to the account closing.
				String body = String.format(
						"Dear %s,\n\n" + "Your account %s" + " has been CLOSED.\n" + transferFunds
								+ "For more information kindly contact branch. \n\n"
								+ "Thank you for banking with us,\n" + "Maveric Banks",
						customer.getFirstName() + " " + customer.getLastName(), accountNumber);
				// Send Email
				if (sendEmail(email, subject, body)) {
					return "mailSent";
				} else
					return "mailFailed";
			} else {
				log.error("Unable to get the customer's email address");
				return "mailNotFound";
			}
		} else {
			log.info("Account Balance is not zero");
			log.error("Failed to close account with account number {}", accountNumber);
			return "nonZero";
		}
	}

	/**
	 * @author vruttantp Template for sending email.
	 * @param email   The email address to which the email has to be sent.
	 * @param subject The subject of the email.
	 * @param body    The content of the email.
	 * @return True if email is sent successfully, false otherwise.
	 */
	private boolean sendEmail(String email, String subject, String body) {
		String url = "http://192.168.97.44:1014/email/sendEmail";
		EmailRequest request = new EmailRequest(email, subject, body);
		ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
		String mailResponse = "";
		if (response.getStatusCode().is2xxSuccessful()) {
			return true;
		} else {
			log.error(response.toString());
			return false;
		}
	}

	/**
	 * @author vruttantp Get Customer details from customerId
	 * @param customerId ID of the customer.
	 * @return Customer customer details.
	 */
	private Customer getCustomer(int customerId) {
		String customerMicroserviceUrl = "http://192.168.97.44:1011/api/retailbanking/customer/fetchCustomer/{customerId}";

		ResponseEntity<CustomerResponse> customerResponseEntity = restTemplate.getForEntity(customerMicroserviceUrl,
				CustomerResponse.class, customerId);

		if (customerResponseEntity.getBody().getData() != null) {
			return customerResponseEntity.getBody().getData();
		} else {
			log.error("Unable to get the customer details from the Customer microservice to send email "
					+ "confirmation to the customer about the account closure for customer ID " + customerId + ".");
			log.error(customerResponseEntity.toString());
		}
		return null;
	}

	/**
	 * @author siddharth Checks if the last ticket for the given customerId,
	 *         accountNumber, and ticketType is rejected. If no ticket exists, it is
	 *         considered as not rejected.
	 *
	 * @param ticketDTO The ticket data transfer object containing customer ID,
	 *                  account number, and ticket type.
	 * @return True if the last ticket is rejected, false otherwise.
	 */
	@Override
	public boolean isLastTicketRejected(TicketDTO ticketDTO) {
		List<Ticket> lastTickets = ticketRepository.findLastByCustomerIdAndAccountNumberAndTicketType(
				ticketDTO.getCustomerId(), ticketDTO.getAccountNumber(), ticketDTO.getTicketType());

		log.debug("Last tickets: {}", lastTickets);

		if (!lastTickets.isEmpty()) {
			// Get the last ticket
			Ticket lastTicket = lastTickets.get(0);

			log.debug("Last ticket: {}", lastTicket);

			// Check if the last ticket status is "Rejected"
			return "Rejected".equals(lastTicket.getTicketStatus());
		}
		// If no ticket exists, consider it as not rejected
		return false;
	}

	/**
	 * @author sonali
	 */
	@Override
	public List<Accounts> getAllBlockedAccounts() {
		// TODO Auto-generated method stub
		return (List<Accounts>) accountRepository
				.findByBlockedAccounts(Arrays.asList(BlockStatus.BLOCKED.toString(), BlockStatus.BOTH.toString(),
						BlockStatus.CREDITBLOCKED.toString(), BlockStatus.DEBITBLOCKED.toString()));
	}

	/**
	 * @author sonali
	 */
	@Override
	public List<Accounts> getBlockedAccountsByCustomerId(Integer customerId) {
		// TODO Auto-generated method stub
		return (List<Accounts>) accountRepository.findBlockedAccountsById(Arrays.asList(BlockStatus.BLOCKED.toString(),
				BlockStatus.BOTH.toString(), BlockStatus.CREDITBLOCKED.toString(), BlockStatus.DEBITBLOCKED.toString()),
				customerId);
	}

	/**
	 * @author siddharthsh Sends an email notification to a customer when a new
	 *         ticket is created.
	 *
	 * @param customerId             The ID of the customer for whom the ticket is
	 *                               being created.
	 * @param accountNumber          The account number associated with the
	 *                               customer.
	 * @param ticketId               The ID of the newly created ticket.
	 * @param ticketType             The type of the ticket (e.g., "Open", "Closed",
	 *                               etc.).
	 * @param transferFund           The type of fund transfer associated with the
	 *                               ticket (e.g., "Transfer to other Account").
	 * @param recipientAccountNumber The account number of the recipient (if
	 *                               applicable).
	 */
	private void sendNewTicketEmailNotification(int customerId, Long accountNumber, Long ticketId, String ticketType,
			String transferFund, Long recipientAccountNumber) {
		// Fetch customer details from the customer microservice to retrieve email
		// address
		Customer customer = getCustomer(customerId);

		if (customer != null) {
			// Get the customer's registered email address
			String email = customer.getEmail();
			String subject = "New Ticket Created";
			String body = String.format(
					"Dear %s,\n\n"
							+ "A new ticket with ID %s has been created for your account with account number %s.\n\n"
							+ "Ticket Type: %s\n" + "Transfer Fund Type: %s\n\n" + "Recipient Account Number: %s\n\n"
							+ "Thank you for banking with us,\n" + "Maveric Banks",
					customer.getFirstName() + " " + customer.getLastName(), ticketId, accountNumber, ticketType,
					transferFund, recipientAccountNumber);
			// Send Email
			sendEmail(email, subject, body);
		} else {
			log.error("Unable to get the customer's email address");
		}
	}
}
