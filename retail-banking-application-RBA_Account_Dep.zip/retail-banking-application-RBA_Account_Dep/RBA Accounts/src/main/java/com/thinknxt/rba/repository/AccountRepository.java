package com.thinknxt.rba.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.thinknxt.rba.config.Generated;
import com.thinknxt.rba.entities.Accounts;

@Repository
@Generated
public interface AccountRepository extends JpaRepository<Accounts, Long> {

	List<Accounts> findByCustomerid(int customerid);

	public Accounts findByAccountnumber(long account_number);

	@Query(value = "SELECT * FROM Accounts a WHERE a.account_status IN (:statuses)", nativeQuery = true)
	public List<Accounts> findByBlockedAccounts(List<String> statuses);
	
	@Query(value = "SELECT * FROM Accounts a WHERE a.account_status IN (:statuses) AND a.customer_id=:customerId", nativeQuery = true)
	public List<Accounts> findBlockedAccountsById(List<String> statuses, Integer customerId);
}
