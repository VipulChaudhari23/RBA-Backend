package com.thinknxt.rba.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.client.match.MockRestRequestMatchers;
import org.springframework.test.web.client.response.MockRestResponseCreators;
import org.springframework.web.client.RestTemplate;

import com.thinknxt.rba.entities.Accounts;
import com.thinknxt.rba.response.AccountResponse;
import com.thinknxt.rba.response.AllAccountsResponse;
import com.thinknxt.rba.response.AllblockResponse;
import com.thinknxt.rba.response.BlockStatusResponse;
import com.thinknxt.rba.response.CustomerAccountResponse;
import com.thinknxt.rba.services.AccountService;
import com.thinknxt.rba.utils.BlockStatus;

public class AccountControllerTest {

	@Mock
	private AccountService accountService;

	@InjectMocks
	private AccountsController accountsController;
	@Mock
	private RestTemplate restTemplate = new RestTemplate();

	@BeforeEach
	public void setUp() {
		// Initialize the mocks
//			MockitoAnnotations.openMocks(this);
//		this.addressRepository = addressRepository;
//		this.customerRepository = customerRepository;
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test for a successful retrieval of customer accounts.
	 */
	@Test
	public void testGetCustomerAccounts_Success() {
		int num = 12345678;
		List<Accounts> mockAccounts = Arrays.asList(
				new Accounts(123456789, 1, "Savings", "Active", "INR", "NO", LocalDateTime.now(), 1000.00, null));
//                new Accounts(987654321, 1, "Checking", "Active", "INR", "YES", Date.valueOf("2022-01-15"), 5000.00));
		when(accountService.getCustomerAccounts(num)).thenReturn(
				new CustomerAccountResponse(mockAccounts, HttpStatus.OK.value(), "Accounts retrieved successfully"));

		ResponseEntity<CustomerAccountResponse> responseEntity = accountsController.getCustomerAccounts(num);

		verify(accountService).getCustomerAccounts(num);

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals("Accounts retrieved successfully", responseEntity.getBody().getMessage());
	}

	/**
	 * Test when no accounts are found for the given customer ID.
	 */
	@Test
	public void testGetCustomerAccounts_NoAccountsFound() {
		int num = 12345678;
		when(accountService.getCustomerAccounts(num)).thenReturn(new CustomerAccountResponse(null,
				HttpStatus.BAD_REQUEST.value(), "No accounts found for the customer"));

		ResponseEntity<CustomerAccountResponse> responseEntity = accountsController.getCustomerAccounts(num);

		verify(accountService).getCustomerAccounts(num);

		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals("No accounts found for the customer", responseEntity.getBody().getMessage());
	}

	@Test
	public void testFetchAccountStatus_AccountNumberNotNull() {
		long accountNumber = 12345L;
		String accountStatus = BlockStatus.BLOCKED.toString();
		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(accountStatus);

		ResponseEntity<String> response = accountsController.fetchAccountStatus(accountNumber);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(accountStatus, response.getBody());
	}

	@Test
	public void testFetchAccountStatus_AccountNumberNull() {
		ResponseEntity<String> response = accountsController.fetchAccountStatus(null);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertEquals("Account number cannot be null ", response.getBody());
	}

	@Test
	public void testFetchAccountStatus_AccountStatusNotPresent() {
		long accountNumber = 12345L;
		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(null);

		ResponseEntity<String> response = accountsController.fetchAccountStatus(accountNumber);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertEquals("Account Status Not Present for " + accountNumber, response.getBody());
	}


	@Test
	public void testGetBlockedAccountsByAccountNumber() {
		// Create a test Accounts object
		Accounts accounts = new Accounts();
		accounts.setAccountnumber(12345L);
		accounts.setAccountstatus("BLOCKED");

		// Set up the mock behavior
		Mockito.when(accountService.fetchAccountDetailsService(Mockito.anyLong())).thenReturn(accounts);

		// Perform the test
		ResponseEntity<AllblockResponse> response = accountsController.getBlockedAccountsByAccountNumber(12345L);

		// Verify the response
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("Retrieved Data for 12345", response.getBody().getMessage());
		assertEquals(200, response.getBody().getStatus());
		assertEquals(accounts, response.getBody().getAccountDetails());
	}

	@Test
	public void testGetBlockedAccountsNotNull() {
		// Create a test Accounts object
		Accounts accounts = new Accounts();
		accounts.setAccountnumber(12345L);
		accounts.setAccountstatus("ACTIVE");

		// Set up the mock behavior
		Mockito.when(accountService.fetchAccountDetailsService(Mockito.anyLong())).thenReturn(accounts);

		// Perform the test
		ResponseEntity<AllblockResponse> response = accountsController.getBlockedAccountsByAccountNumber(12345L);

		// Verify the response
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("12345 is not Blocked", response.getBody().getMessage());
		assertEquals(301, response.getBody().getStatus());
		assertEquals(null, response.getBody().getAccountDetails());
	}

	@Test
	public void testGetBlockedAccountsNotPresent() {
		// Create a test Accounts object
		Accounts accounts = new Accounts();
		accounts.setAccountnumber(12345L);
		accounts.setAccountstatus("");

		// Set up the mock behavior
		Mockito.when(accountService.fetchAccountDetailsService(Mockito.anyLong())).thenReturn(null);

		// Perform the test
		ResponseEntity<AllblockResponse> response = accountsController.getBlockedAccountsByAccountNumber(12345L);

		// Verify the response
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("12345 is not Present.", response.getBody().getMessage());
		assertEquals(302, response.getBody().getStatus());
	}

	@Test
	public void testGetBlockedAccountsByCustomerId() {
		// Create a test Accounts object
		List<Accounts> accounts = new ArrayList<>();
		Accounts account1 = new Accounts();
		account1.setAccountnumber(12345L);
		account1.setAccountstatus("BLOCKED");
		accounts.add(account1);

		// Set up the mock behavior
		Mockito.when(accountService.getBlockedAccountsByCustomerId(Mockito.anyInt())).thenReturn(accounts);

		// Perform the test
		ResponseEntity<AllblockResponse> response = accountsController.getBlockedAccountsByCustomerId(123);

		// Verify the response
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("Blocked Accounts retrieved successfully for 123", response.getBody().getMessage());
		assertEquals(200, response.getBody().getStatus());
	}

	@Test
	public void testGetBlockedAccountsByCustomerId_NotPresent() {
		// Create a test Accounts object
		List<Accounts> accounts = new ArrayList<>();
		Accounts account1 = new Accounts();
		account1.setAccountnumber(12345L);
		account1.setAccountstatus("ACTIVE");
		accounts.add(account1);

		// Set up the mock behavior
		Mockito.when(accountService.getBlockedAccountsByCustomerId(Mockito.anyInt())).thenReturn(null);

		// Perform the test
		ResponseEntity<AllblockResponse> response = accountsController.getBlockedAccountsByCustomerId(123);

		// Verify the response
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("No Blocked accounts found for 123", response.getBody().getMessage());
		assertEquals(302, response.getBody().getStatus());
	}

	@Test
	public void testGetAllBlockedAccounts() {
		// Create a test Accounts object
		List<Accounts> accounts = new ArrayList<>();
		Accounts account1 = new Accounts();
		account1.setAccountnumber(12345L);
		account1.setAccountstatus("BLOCKED");
		accounts.add(account1);

		// Set up the mock behavior
		Mockito.when(accountService.getAllBlockedAccounts()).thenReturn(accounts);

		// Perform the test
		ResponseEntity<AllAccountsResponse> response = accountsController.getAllBlockedAccounts();

		// Verify the response
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("Accounts retrieved successfully", response.getBody().getMessage());
		assertEquals(200, response.getBody().getStatus());
		assertEquals(accounts, response.getBody().getData());
	}

	@Test
	public void testGetAllBlockedAccounts_NoAccountsFound() {
		// Create a test Accounts object
		List<Accounts> accounts = new ArrayList<>();
		Accounts account1 = new Accounts();
		account1.setAccountnumber(12345L);
		account1.setAccountstatus("ACTIVE");
		accounts.add(account1);

		// Set up the mock behavior
		Mockito.when(accountService.getAllBlockedAccounts()).thenReturn(null);

		// Perform the test
		ResponseEntity<AllAccountsResponse> response = accountsController.getAllBlockedAccounts();

		// Verify the response
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("No accounts found", response.getBody().getMessage());
		assertEquals(302, response.getBody().getStatus());
	}

	@Test
	public void testGetAccountDetails() {
		// Create a test account number
		Long accountNumber = 12345L;

		// Create a test account object
		Accounts account = new Accounts();
		account.setAccountnumber(accountNumber);
		account.setAccountstatus("ACTIVE");
		account.setCustomerid(1);

		// Set up the mock behavior
		Mockito.when(accountService.fetchAccountDetailsService(accountNumber)).thenReturn(account);

		// Perform the test
		ResponseEntity<?> response = accountsController.getAccountDetails(accountNumber);

		// Verify the response
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(account, response.getBody());
	}

	@Test
	public void testGetAccountDetailsWithNullAccountNumber() {
		// Set up the mock behavior
		Mockito.when(accountService.fetchAccountDetailsService(0)).thenReturn(null);

		// Perform the test
		ResponseEntity<?> response = accountsController.getAccountDetails(null);

		// Verify the response
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertEquals("Account number cannot be null ", response.getBody());
	}

	@Test
	public void testGetAccountDetailsWithNonExistentAccount() {
		// Create a test account number
		Long accountNumber = 12345L;

		// Set up the mock behavior
		Mockito.when(accountService.fetchAccountDetailsService(accountNumber)).thenReturn(null);

		// Perform the test
		ResponseEntity<?> response = accountsController.getAccountDetails(accountNumber);

		// Verify the response
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertEquals("Account Details not present", response.getBody());
	}

	@Test
	public void testUpdateAmount() {
		// Create test parameters
		Double newAmount = 500.0;
		Long accountNumber = 12345L;

		// Set up the mock behavior
		doNothing().when(accountService).updateAmount(newAmount, accountNumber);

		// Perform the test
		ResponseEntity<Void> response = accountsController.updateAmount(newAmount, accountNumber);

		// Verify the response
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testUpdateAccountStatus_AlreadyBlocked() {
		long accountNumber = 123456L;
		String accountStatus = "BLOCKED";

		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(accountStatus);

//		doReturn("Status Updated Successfully as " + accountStatus).when(accountService)
//				.updateAccountStatus(accountNumber, accountStatus, "Test");

		ResponseEntity<BlockStatusResponse> responseEntity = accountsController.updateAccountStatus(accountNumber,
				accountStatus, "Test");

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(" Already blocked for 123456", responseEntity.getBody().getStatusMessage());

	}

	@Test
	public void testUpdateAccountStatus_ACTIVE() {
		long accountNumber = 123456L;
		String dbaccountStatus = "ACTIVE";
		String accountStatus = "BLOCKED";

		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(dbaccountStatus);

//		doReturn("Status Updated Successfully as " + accountStatus).when(accountService)
//				.updateAccountStatus(accountNumber, accountStatus, "Test");

		ResponseEntity<BlockStatusResponse> responseEntity = accountsController.updateAccountStatus(accountNumber,
				accountStatus, "Test");

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testUpdateAccountStatus_CREDITBLOCKED() {
		long accountNumber = 123456L;
		String dbaccountStatus = "CREDITBLOCKED";
		String accountStatus = "BLOCKED";

		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(dbaccountStatus);

//		doReturn("Status Updated Successfully as " + accountStatus).when(accountService)
//				.updateAccountStatus(accountNumber, accountStatus, "Test");

		ResponseEntity<BlockStatusResponse> responseEntity = accountsController.updateAccountStatus(accountNumber,
				accountStatus, "Test");

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testUpdateAccountStatus_BadRequest() {
		long accountNumber = 123456L;
		String dbaccountStatus = null;
		String accountStatus = "gsdgfjs";

		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(dbaccountStatus);

//		doReturn("Status Updated Successfully as " + accountStatus).when(accountService)
//				.updateAccountStatus(accountNumber, accountStatus, "Test");

		ResponseEntity<BlockStatusResponse> responseEntity = accountsController.updateAccountStatus(accountNumber,
				accountStatus, "Test");

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}

	@Test
	public void testUnblockAccount_whenStatusIsBlockedAndRequestIsForCreditUnblock_thenStatusShouldBeUpdatedToDebitBlocked() {
		// Given
		Long accountNumber = 12345L;
		String accountStatus = "CREDITUNBLOCK";
		String reason = "testReason";
		String currentStatus = BlockStatus.BLOCKED.toString();
		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(currentStatus);

		// When
		ResponseEntity<BlockStatusResponse> responseEntity = accountsController.unblockAccount(accountNumber,
				accountStatus, reason);

		// Then
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertNotNull(responseEntity.getBody());
	}

	@Test
	public void testUnblockAccount_whenStatusIsBlockedAndRequestIsForDebitUnblock_thenStatusShouldBeUpdatedToCreditBlocked() {
		// Given
		Long accountNumber = 12345L;
		String accountStatus = "DEBITUNBLOCK";
		String reason = "testReason";
		String currentStatus = BlockStatus.BLOCKED.toString();
		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(currentStatus);

		// When
		ResponseEntity<BlockStatusResponse> responseEntity = accountsController.unblockAccount(accountNumber,
				accountStatus, reason);

		// Then
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertNotNull(responseEntity.getBody());
	}

	@Test
	public void testUnblockAccount_whenStatusIsBlockedAndRequestIsForFullUnblock_thenStatusShouldBeUpdatedToActive() {
		// Given
		Long accountNumber = 12345L;
		String accountStatus = "ACTIVE";
		String reason = "testReason";
		String currentStatus = BlockStatus.BLOCKED.toString();
		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(currentStatus);

		// When
		ResponseEntity<BlockStatusResponse> responseEntity = accountsController.unblockAccount(accountNumber,
				accountStatus, reason);

		// Then
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertNotNull(responseEntity.getBody());
	}

	@Test
	public void testUnblockAccount_CreditUnblock() {
		// Given
		Long accountNumber = 12345L;
		String accountStatus = "CREDITUNBLOCK";
		String reason = "testReason";
		String currentStatus = BlockStatus.CREDITBLOCKED.toString();
		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(currentStatus);

		// When
		ResponseEntity<BlockStatusResponse> responseEntity = accountsController.unblockAccount(accountNumber,
				accountStatus, reason);

		// Then
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertNotNull(responseEntity.getBody());
	}

	@Test
	public void testUnblockAccount_DebitUnblock() {
		// Given
		Long accountNumber = 12345L;
		String accountStatus = "DEBITUNBLOCK";
		String reason = "testReason";
		String currentStatus = BlockStatus.DEBITBLOCKED.toString();
		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(currentStatus);

		// When
		ResponseEntity<BlockStatusResponse> responseEntity = accountsController.unblockAccount(accountNumber,
				accountStatus, reason);

		// Then
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertNotNull(responseEntity.getBody());
	}

	@Test
	public void testUnblockAccount() {
		// Given
		Long accountNumber = 12345L;
		String accountStatus = null;
		String reason = "testReason";
		String currentStatus = BlockStatus.DEBITBLOCKED.toString();
		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(currentStatus);

		// When
		ResponseEntity<BlockStatusResponse> responseEntity = accountsController.unblockAccount(accountNumber,
				accountStatus, reason);

		// Then
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertNotNull(responseEntity.getBody());
	}

	@Test
	public void testUnblockAccount_null() {
		// Given
		Long accountNumber = 12345L;
		String accountStatus = null;
		String reason = "testReason";
		String currentStatus = null;
		when(accountService.fetchAccountStatusService(accountNumber)).thenReturn(currentStatus);

		// When
		ResponseEntity<BlockStatusResponse> responseEntity = accountsController.unblockAccount(accountNumber,
				accountStatus, reason);

		// Then
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertNotNull(responseEntity.getBody());
	}

//	@Configuration
//	static class TestConfig {
//		@Primary
//		@Bean
//		public RestTemplate restTemplate() {
//			return new RestTemplate();
//		}
//	}
}